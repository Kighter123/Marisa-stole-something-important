#include "StartPage.h"

StartPage::StartPage(QWidget *parent) : QWidget(parent)
{

    pageImage.load(":/StartPage.png");
    Title.load(":/Title1.png");
    // 创建开始按钮
    startButton = new QPushButton("游戏开始", this);
    startButton->setStyleSheet("font-size: 80px; color: yellow; background-color: transparent; border: black;");
    startButton->setCursor(Qt::PointingHandCursor);

    // 创建布局
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addStretch(2);
    layout->addWidget(startButton, 1, Qt::AlignCenter);
    setLayout(layout);

    // 设置背景
    setFixedSize(1120, 800);//窗口大小

    // 创建动画

    // 连接信号和槽
    startButton->installEventFilter(this);
    connect(startButton, &QPushButton::clicked, this, &StartPage::onStartButtonClicked);
}

void StartPage::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    painter.drawImage(0, 0, pageImage.scaled(size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
    painter.drawImage(80, 160, Title.scaled(size()*5/7, Qt::IgnoreAspectRatio, Qt::SmoothTransformation));

}
StartPage::~StartPage()
{
    delete startButton;
    delete layout();
}


void StartPage::onStartButtonClicked()
{
    emit startGameClicked();
}

