#include "GameWindow.h"
#include "SuccessWindow.h"
#include "StartPage.h"
#include "FailureWindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    GameWindow w;
    StartPage s;
    SuccessWindow s1;
    FailureWindow f;

    w.timeForPrepare();
    s.show();

    // 从开始页面到游戏页面
    QObject::connect(&s, &StartPage::startGameClicked, [&]() {
        w.timeForStart();
        s.hide();
        w.show();

    });
    QObject::connect(&w, &GameWindow::gameSuccess, [&]() {
        s1.showScore(w.getScore());
        w.hide();
        w.deleteGame();
        s1.show();
    });
    QObject::connect(&w,&GameWindow::gameFailure,[&](){
        w.hide();
        w.deleteGame();
        f.show();
   });
    return a.exec();
}
