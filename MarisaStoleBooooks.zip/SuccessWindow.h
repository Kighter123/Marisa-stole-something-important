#ifndef SUCCESSWINDOW_H
#define SUCCESSWINDOW_H

#include <QWidget>
#include <QEvent>
#include <QRect>
#include <QPainter>
class SuccessWindow : public QWidget
{
    Q_OBJECT

public:
    void paintEvent(QPaintEvent *event) override;
    SuccessWindow(QWidget *parent = nullptr);
    ~SuccessWindow();
    void showScore(int score);

private:
    int score;
    QImage Title;
    QImage pageImage;
};

#endif // SUCCESSWINDOW_H
