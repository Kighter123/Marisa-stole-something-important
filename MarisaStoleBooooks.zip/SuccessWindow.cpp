#include "SuccessWindow.h"
SuccessWindow::SuccessWindow(QWidget *parent):
    QWidget(parent)

{
    pageImage.load(":/SuccessPage.png");
    Title.load(":/SuccessImage.png");
    setFixedSize(1120, 800);

}

void SuccessWindow::paintEvent(QPaintEvent *event) {

    //窗口初始化绘制
    QPainter painter(this);


    //绘制背景
    painter.drawImage(0, 0, pageImage.scaled(width(), height()));
    painter.drawImage(450, 20, Title.scaled(size()*4/7, Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
    // 绘制分数
    painter.setPen(QColorConstants::Svg::purple);
    painter.setFont(QFont("Arial", 60));
    painter.drawText(600, 550, QString("您的得分:"));
    painter.setPen(Qt::yellow);
    painter.setFont(QFont("Arial", 60));
    painter.drawText(680, 650, QString("%1").arg(score));

}

void SuccessWindow::showScore(int scoreTrans){
    score=scoreTrans;
}

SuccessWindow::~SuccessWindow(){}
