#ifndef STARTPAGE_H
#define STARTPAGE_H

#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QEvent>
#include <QRect>
#include <QPainter>
class StartPage : public QWidget
{
    Q_OBJECT

public:
    void paintEvent(QPaintEvent *event) override;
    StartPage(QWidget *parent = nullptr);
    ~StartPage();

signals:
    void startGameClicked();

private slots:
    void onStartButtonClicked();

private:
    QPushButton *startButton;
    QImage Title;
    QImage pageImage;
};

#endif // STARTPAGE_H
