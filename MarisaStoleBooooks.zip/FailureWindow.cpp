#include "FailureWindow.h"

FailureWindow::FailureWindow(QWidget *parent):
    QWidget(parent)

{
    pageImage.load(":/failure.png");
    Title.load(":/failureImage.png");
    setFixedSize(1120, 800);

}

void FailureWindow::paintEvent(QPaintEvent *event) {

    //窗口初始化绘制
    QPainter painter(this);


    //绘制背景
    painter.drawImage(0, 0, pageImage.scaled(width(), height()));
    painter.drawImage(250, 300, Title.scaled(size()*4/7, Qt::IgnoreAspectRatio, Qt::SmoothTransformation));

}
