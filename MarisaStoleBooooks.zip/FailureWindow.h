#ifndef FAILUREWINDOW_H
#define FAILUREWINDOW_H

#include <QWidget>
#include <QEvent>
#include <QRect>
#include <QPainter>
class FailureWindow : public QWidget
{
    Q_OBJECT

public:
    void paintEvent(QPaintEvent *event) override;
    FailureWindow(QWidget *parent = nullptr);
    //~FailureWindow();

private:
    QImage Title;
    QImage pageImage;
};

#endif // FAILUREWINDOW_H
