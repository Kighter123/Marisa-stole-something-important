#ifndef PLAYER_H
#define PLAYER_H

#include <QRect>
#include <QPainter>
#include <QDateTime>
#include <QTimer>
#include "Obstacle.h"
#include "HorizontalObstacle.h"

class Ground;

class Bullet {
public:
    int x, y;
    float v;
    int sx,sy;
    int tx,ty;
    float dx, dy;
    QImage ball;
    static const int width = 20;
    static const int height = 20;

    Bullet(int startX, int startY, int targetX, int targetY) {
        ball.load(":/magicBalls.png");
        sx = startX;
        sy = startY;
        tx = targetX;
        ty = targetY;
        x = startX;
        y = startY;
        v=8;
        float diffX = tx-sx;
        float diffY = ty-sy;
        float length = std::sqrt(diffX * diffX + diffY * diffY);


        if (length != 0) {
            dx = diffX * v / length; // 子弹速度
            dy = diffY * v / length;
        } else {
            dx = 0;
            dy = 0;
        }
    }

    void move(int startX, int startY) {
        x += dx;
        y += dy;
        float distance=std::sqrt((x-startX)*(x-startX) + (y-startY)*(y-startY));
        v = distance>144?12*7/std::sqrt(distance):7;
        float diffX = tx-sx;
        float diffY = ty-sy;
        float length = std::sqrt(diffX * diffX + diffY * diffY);
        dx = diffX * v / length; // 子弹速度
        dy = diffY * v / length;
    }

    QRect rect() const {
        return QRect(x, y, width, height);
    }
};

class Player {
public:

    Player(int windowWidth, int lifeCount);
    ~Player();
    void draw(QPainter *painter);
    void move(int dx);
    void jump();
    void update(const Ground *ground);
    QRect rect() const;
    QRect rectWithRewardBlock() const;
    void lifeDown();
    int getLife();
    void activateInvincibility();
    bool isInvincible() const;
    void scoreSkillAt_Z(int& score);
    void scoreSkillAt_X(int& score, QList<Obstacle*>& obstacles);
    void pause();
    void faceSideChange();
    void startGlide();
    void stopGlide();
    void checkGlide();
    void addGlideEnergy();
    int getEnergy();
    void shoot(int targetX, int targetY);
    void updateBullets(const QList<Obstacle*>& obstacles, const QList<HorizontalObstacle*>& horiObstacles);
    static const int MAX_BULLETS = 15;

private:
    bool faceSide;
    int lifeCount;
    int x, y;
    int windowWidth;
    float gravity;
    float velocityX;
    float velocityY;
    bool isJumping;
    bool doubleJumping;
    int groundY;
    bool isGliding;
    QImage playerImage1;
    QImage playerImage0;
    QImage glideImage;
    static const int width = 50;
    static const int height = 50;
    static const int realWidth = 4;
    static const int realHeight = 4;
    bool invincible;
    qint64 invincibleEndTime;
    QTimer *glideTimer;
    bool checkKeyPressed;
    float glideEnergy;
    static const float maxGlideEnergy;
    static const float glideEnergyConsumption;
    Bullet* bullets[MAX_BULLETS];
    int bulletCount;
};

#endif
